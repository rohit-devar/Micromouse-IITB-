# ROS Learning Resources

ROS Robot Programming Book: http://wiki.ros.org/Books/ROS_Robot_Programming_English

A Gentle Introduction to ROS Book: https://www.cse.sc.edu/~jokane/agitr/